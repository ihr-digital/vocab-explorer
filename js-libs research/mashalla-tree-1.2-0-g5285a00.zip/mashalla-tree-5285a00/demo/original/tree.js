
window.addEvent('domready', function(){

    new Collapse('collapse');
});
